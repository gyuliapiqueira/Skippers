// Função para mostrar o tooltip
function mostrarTooltip() {
    document.getElementById("tooltip-linhas").style.display = "block";
}

// Função para esconder o tooltip
function esconderTooltip() {
    document.getElementById("tooltip-linhas").style.display = "none";
}

// Função para mostrar o tooltip
function mostrarTooltipP() {
    document.getElementById("tooltip-primarios").style.display = "block";
}

// Função para esconder o tooltip
function esconderTooltipP() {
    document.getElementById("tooltip-primarios").style.display = "none";
}

// Função para mostrar o tooltip
function mostrarTooltipQ() {
    document.getElementById("tooltip-quasi").style.display = "block";
}

// Função para esconder o tooltip
function esconderTooltipQ() {
    document.getElementById("tooltip-quasi").style.display = "none";
}

// Função para mostrar o tooltip
function mostrarTooltipC() {
    document.getElementById("tooltip-compartilhamento").style.display = "block";
}

// Função para esconder o tooltip
function esconderTooltipC() {
    document.getElementById("tooltip-compartilhamento").style.display = "none";
}

// Função para mostrar o tooltip
function mostrarTooltipD() {
    document.getElementById("tooltip-dadosSensiveis").style.display = "block";
}

// Função para esconder o tooltip
function esconderTooltipD() {
    document.getElementById("tooltip-dadosSensiveis").style.display = "none";
}

// Função para mostrar o tooltip
function mostrarTooltipIc() {
    document.getElementById("tooltip-idososCriancas").style.display = "block";
}

// Função para esconder o tooltip
function esconderTooltipIc() {
    document.getElementById("tooltip-idososCriancas").style.display = "none";
}

// Função para mostrar o tooltip
function mostrarTooltipDF() {
    document.getElementById("tooltip-dadosFinanceiros").style.display = "block";
}

// Função para esconder o tooltip
function esconderTooltipDF() {
    document.getElementById("tooltip-dadosFinanceiros").style.display = "none";
}

function calcularRisco() {
    // Obter valores do formulário
    const linhas = parseFloat(document.getElementById("linhas").value);
    const quasiIdentificadores = parseFloat(document.getElementById("quasi-identificadores").value);
    const identificadoresPrimarios = parseFloat(document.getElementById("identificadores-primarios").value);

    let compartilhamento = 0;
    const internoChecked = document.getElementById("interno").checked;
    const externoChecked = document.getElementById("externo").checked;
    const internacionalChecked = document.getElementById("internacional").checked;

    if (internoChecked) compartilhamento += parseFloat(document.getElementById("interno").value);
    if (externoChecked) compartilhamento += parseFloat(document.getElementById("externo").value);
    if (internacionalChecked) compartilhamento += parseFloat(document.getElementById("internacional").value);

    // Se todos os três campos de compartilhamento estiverem selecionados, define o peso como 1,2
    if(internoChecked && externoChecked && internacionalChecked){
        compartilhamento = 1.2;
    }

    const dadosSensiveis = document.getElementById("dados-sensiveis").checked ? 1 : 0;
    const dadosMenores = document.getElementById("dados-menores").checked ? 1 : 0;
    const dadosFinanceiros = document.getElementById("dados-financeiros").checked ? 1 : 0;

    // Calcular probabilidade
    const probabilidade = linhas + quasiIdentificadores + identificadoresPrimarios + compartilhamento;

    // Calcular impacto com valor padrão mínimo de 1 se nenhum campo do impacto for selecionado
    let impacto = dadosSensiveis + dadosMenores + dadosFinanceiros;
    if (impacto === 0){
        impacto = 1; // Define um valor mínimo para evitar que na multiplicação o valor de impacto resulte em 0
    }

    // Calcular soma total
    const total = probabilidade * impacto;

  // Verificar o nível de risco
let nivelRisco = ""; 
let imagemRisco = ""; // Variável para armazenar o caminho da imagem

if (probabilidade <= 1 && impacto <= 1) {
    nivelRisco = "O nível de risco de reidentificação da sua base de dados é <b>baixo</b>!";
    imagemRisco = "imgs/quadrantes/pb(1) e i(1).png"; // Caminho da imagem para risco baixo - quadrante baixo
} else if (probabilidade > 1 && probabilidade <=2 && impacto <= 1) {
    nivelRisco = "O nível de risco de reidentificação da sua base de dados é <b>baixo</b>!";
    imagemRisco = "imgs/quadrantes/pb(2) e i(1).png"; // Caminho da imagem para risco baixo - quadrante médio
} else if (probabilidade <=1 && impacto > 1 && impacto <=2) {
    nivelRisco = "O nível de risco de reidentificação da sua base de dados é <b>baixo</b>!";
    imagemRisco = "imgs/quadrantes/pb(1) e i(2).png"; // Caminho da imagem para risco baixo - quadrante alto
} else if (probabilidade <=1 && impacto > 2 && impacto <=3) {
    nivelRisco = "Atente-se. O nível de risco de reidentificação da sua base de dados é <b>médio</b>.";
    imagemRisco = "imgs/quadrantes/pb(1) e i(3).png"; // Caminho da imagem para risco médio - quadrante baixo
} else if (probabilidade > 1  && probabilidade <= 2 && impacto > 1 && impacto <= 2) {
    nivelRisco = "Atente-se. O nível de risco de reidentificação da sua base de dados é <b>médio</b>.";
    imagemRisco = "imgs/quadrantes/pb(2) e i (2).png"; // Caminho da imagem para risco médio - quadrante médio
} else if (probabilidade >=2  && impacto <= 1)  {
    nivelRisco = "Atente-se. O nível de risco de reidentificação da sua base de dados é <b>médio</b>.";
    imagemRisco = "imgs/quadrantes/pb(3) e i (1).png";
} else if (probabilidade == 3.0 && impacto == 3.0){
    nivelRisco = "Cuidado!⚠️ O nível de risco de reidentificação da sua base de dados é <b>alto</b>.";
    imagemRisco = "imgs/quadrantes/pb(3)ei(3).png"; // Caminho da imagem para risco alto - quadrante alto
} else if (probabilidade > 1 && probabilidade <= 2 && impacto >= 2){
    nivelRisco = "Cuidado!⚠️ O nível de risco de reidentificação da sua base de dados é <b>alto</b>.";
    imagemRisco = "imgs/quadrantes/pb(2) e i(3).png"; // Caminho da imagem para risco alto - quadrante alto
} else if (probabilidade >= 2 && impacto >= 2){
    nivelRisco = "Cuidado!⚠️ O nível de risco de reidentificação da sua base de dados é <b>alto</b>.";
    imagemRisco = "imgs/quadrantes/pb(3)ei(2).png"; // Caminho da imagem para risco alto - quadrante alto
}

// Exibir resultado com a imagem correspondente
document.getElementById("resultado").innerHTML = `
    <p>${nivelRisco}</p>
    <img src="${imagemRisco}" style="width: 300px; height: auto; margin-left: -70px">
`;

// <p>${total}</p>
// <p>${impacto}</p>
// <p>${probabilidade}</p>

    // Ativar o efeito de flip
    document.querySelector('.caixa-flip').classList.add('flip-active');
}

function voltarFormulario() {
    // Voltar para o formulário
    document.querySelector('.caixa-flip').classList.remove('flip-active');
}

// Função para rolar até a calculadora
function rolarParaCalculadora(){
    document.getElementById("calculadora").scrollIntoView({ behavior: "smooth" });
}


$(document).ready(function() {
    $('#onoff-sensiveis').on('change', function() {
        var el = this;
        $.ajax({
            url: "save.php",
            data: {
                estado: this.checked
            }
        }).done(function(msg) {
            if (msg == 'failed') return el.checked = !el.checked; // caso o servidor retorne "failed" mudar o estado do botão
            else alert("Info gravada: " + msg);
        });
    });

    $('#onoff-menores').on('change', function() {
        var el = this;
        $.ajax({
            url: "save.php",
            data: {
                estado: this.checked
            }
        }).done(function(msg) {
            if (msg == 'failed') return el.checked = !el.checked; 
            else alert("Info gravada: " + msg);
        });
    });

    $('#onoff-financeiros').on('change', function() {
        var el = this;
        $.ajax({
            url: "save.php",
            data: {
                estado: this.checked
            }
        }).done(function(msg) {
            if (msg == 'failed') return el.checked = !el.checked;
            else alert("Info gravada: " + msg);
        });
    });
});
